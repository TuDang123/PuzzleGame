
start();	


// clock
var minutesLabel = document.getElementById("minutes");
var secondsLabel = document.getElementById("seconds");
var totalSeconds = 0;
setInterval(setTime, 1000);

function setTime() {
  ++totalSeconds;
  secondsLabel.innerHTML = pad(totalSeconds % 60);
  minutesLabel.innerHTML = pad(parseInt(totalSeconds / 60));
}

function pad(val) {
  var valString = val + "";
  if (valString.length < 2) {
    return "0" + valString;
  } else {
    return valString;
  }
}


// remove clock, show VICTORY text
function victory(){
	//
	var ele = document.getElementById("time");
	ele.remove();
	
	
	
	//
	var text = document.createTextNode("You WON!");
	var p = document.createElement("p");
	p.appendChild(text);
	var x = document.getElementsByClassName("salute");
	x[0].appendChild(p);
	
}





// random values in boxes and insert the value
function start() {
  var puzzleValues = [1, 2, 3, 4, 5, 6, 7, 8,  ""],
      $puzzleBox = $(".puzzle");
  $puzzleBox.html("");
  for (let i=0; i<9; i++) {
    var $newDiv = $("<div>");
    let numb = random(puzzleValues);
    $newDiv.html(numb);
    $newDiv.addClass("boxs box"+numb);
    $puzzleBox.append($newDiv);
  }
  $(".box").css("background-image", "none");
  $puzzleboxs = $(".boxs");
  move();
}


// Every movement, check if the game is done
function checkIFwon() {
	
	
  let checkIFwonArr = [];
  for (let i=0; i<9; i++) {
    if ($(".boxs").eq(i).hasClass("box"+(i+1))) {
      checkIFwonArr.push(i+1);
    //  console.log(checkIFwonArr);
    }
  }
  if (checkIFwonArr.length === 8) {
    $(".box").css("background-image", "url(https://i.pinimg.com/originals/a0/3e/33/a03e33144273d75b7799ec5ffd8eba14.jpg)");
    setTimeout(function() {
      victory();
    }, 200);
  }
}


// takes random element af an array and deletes it
function random(arr) {
  let rand = Math.floor(Math.random() * arr.length);
  let toReturn = arr[rand];
  arr.splice(rand, 1);
  return toReturn; 
}

// change 2 elts positions in DOM
function swapElts(elt1, elt2) {
  var $temp = $("<div>");
  elt1.before($temp);
  elt2.before(elt1);
  $temp.before(elt2);
  $temp.remove;
}

// when user clicks, move the clicked box to the 'empty' box
function move() {
  $(".boxs").on("click", function(e) {
	  
	
	  
	  
	  
    // box 0
    if ($(this).is($(".boxs").eq(0))) {
      if      ($(".boxs").eq(1).hasClass("box")) swapElts($(this), $(".boxs").eq(1));
      else if ($(".boxs").eq(3).hasClass("box")) swapElts($(this), $(".boxs").eq(3));
    }
    // box 1
    else if ($(this).is($(".boxs").eq(1))) {
      if      ($(".boxs").eq(0).hasClass("box")) swapElts($(this), $(".boxs").eq(0));
      else if ($(".boxs").eq(2).hasClass("box")) swapElts($(this), $(".boxs").eq(2));
      else if ($(".boxs").eq(4).hasClass("box")) swapElts($(this), $(".boxs").eq(4));
    }
    // box 2
    else if ($(this).is($(".boxs").eq(2))) {
      if      ($(".boxs").eq(1).hasClass("box")) swapElts($(this), $(".boxs").eq(1));
      else if ($(".boxs").eq(5).hasClass("box")) swapElts($(this), $(".boxs").eq(5));
    }
    // box 3
    else if ($(this).is($(".boxs").eq(3))) {
      if      ($(".boxs").eq(0).hasClass("box")) swapElts($(this), $(".boxs").eq(0));
      else if ($(".boxs").eq(4).hasClass("box")) swapElts($(this), $(".boxs").eq(4));
      else if ($(".boxs").eq(6).hasClass("box")) swapElts($(this), $(".boxs").eq(6));
    }
    // box 4
    else if ($(this).is($(".boxs").eq(4))) {
      if      ($(".boxs").eq(1).hasClass("box")) swapElts($(this), $(".boxs").eq(1));
      else if ($(".boxs").eq(3).hasClass("box")) swapElts($(this), $(".boxs").eq(3));
      else if ($(".boxs").eq(5).hasClass("box")) swapElts($(this), $(".boxs").eq(5));
      else if ($(".boxs").eq(7).hasClass("box")) swapElts($(this), $(".boxs").eq(7));
    }
    // box 5
    else if ($(this).is($(".boxs").eq(5))) {
      if      ($(".boxs").eq(2).hasClass("box")) swapElts($(this), $(".boxs").eq(2));
      else if ($(".boxs").eq(4).hasClass("box")) swapElts($(this), $(".boxs").eq(4));
      else if ($(".boxs").eq(8).hasClass("box")) swapElts($(this), $(".boxs").eq(8));
    }
    // box 6
    else if ($(this).is($(".boxs").eq(6))) {
      if      ($(".boxs").eq(3).hasClass("box")) swapElts($(this), $(".boxs").eq(3));
      else if ($(".boxs").eq(7).hasClass("box")) swapElts($(this), $(".boxs").eq(7));
    }
    // box 7
    else if ($(this).is($(".boxs").eq(7))) {
      if      ($(".boxs").eq(4).hasClass("box")) swapElts($(this), $(".boxs").eq(4));
      else if ($(".boxs").eq(6).hasClass("box")) swapElts($(this), $(".boxs").eq(6));
      else if ($(".boxs").eq(8).hasClass("box")) swapElts($(this), $(".boxs").eq(8));
    }
    // box 8
    else if ($(this).is($(".boxs").eq(8))) {
      if      ($(".boxs").eq(5).hasClass("box")) swapElts($(this), $(".boxs").eq(5));
      else if ($(".boxs").eq(7).hasClass("box")) swapElts($(this), $(".boxs").eq(7));
    }
    // perform the checkIFwon
	
    checkIFwon();
  });
}
